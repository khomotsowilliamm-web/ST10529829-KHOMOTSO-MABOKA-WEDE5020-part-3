# Urban Crust Bakery — WEDE5020 Part 3

**Student:** Khomotso Maboka  
**Student number:** ST10529829  
**Module:** WEDE5020 — Web Development (Introduction)  
**Project:** Urban Crust Bakery (fictional small business)

## Project overview

Part 3 extends the existing Part 1 HTML pages and Part 2 responsive CSS design. It keeps the same five-page website, organisation, cream/brown/soft-orange visual identity, navigation labels, product names, example prices, email recipient and Johannesburg location information.

## Website files

- `index.html` — homepage and bakery introduction
- `about.html` — story, mission, vision, customers and interactive FAQ accordion
- `products.html` — bakery products, live search/filter and clickable image lightbox
- `enquiry.html` — product/custom-cake enquiry with JavaScript validation and email preparation
- `contact.html` — general contact form, branch details and interactive Leaflet map with both branches
- `style.css` — shared responsive styling retained from Part 2 and extended for Part 3
- `js/main.js` — shared JavaScript features loaded with `defer`
- `robots.txt` — crawler instructions
- `sitemap.xml` — sitemap template; update the placeholder domain before publishing

## Part 3 functionality

### 1. Interactive elements
- FAQ accordion on the About page; buttons expose and collapse answers and update `aria-expanded`.
- Product image lightbox on the Products page; images open in a larger modal and close by button, Escape key or clicking the backdrop.
- Live product search filters product cards by their visible text and updates the result count; a sort control orders products by name or listed price.
- Interactive Leaflet map on the Contact page with a marker and popup for each of the two branches (example coordinates for the fictional addresses).
- CSS transitions and keyframe animations (card hover lift, image zoom, hero fade-in, lightbox and FAQ fade) with `prefers-reduced-motion` support.
- CSS hover/focus states and reduced-motion support help the interactive elements remain usable.

### 2. Forms and validation
- The Enquiry form is for a product, quantity, preferred collection date and optional custom cake requirements. JavaScript validates fields and displays an estimated listed starting total for products with example prices. The bakery must confirm actual availability and price.
- The Contact form is for general messages, including a message type and full message.
- Both forms show validation feedback and prepare a `mailto:` email for `info@urbancrustbakery.co.za`.
- **Important limitation:** `mailto:` requires a compatible email application and the visitor must press Send. This static website does not send email itself or store submissions. A hosted form service or server endpoint would be required for reliable direct submission/AJAX processing.

### 3. SEO
- Each page has a page-specific title, meta description and meta keywords.
- Semantic headings, descriptive image alt text, internal navigation and responsive layouts are retained.
- `robots.txt` and `sitemap.xml` are included. Replace `https://YOUR-DEPLOYED-DOMAIN` in both files with the actual published domain, then resubmit the sitemap to search tools if desired.
- Product image URLs use descriptive alt text and lazy loading where applicable.
- Local SEO content refers to the fictional bakery's stated Johannesburg branches. The addresses and contact details are project examples and should not be represented as a real operating business.

### 4. Responsive design
The Part 2 stylesheet is preserved. It includes the existing desktop, tablet and mobile breakpoints, Grid/Flexbox layouts, responsive images, accessible focus styles and cream/brown/orange palette. New Part 3 styles cover search, validation feedback, FAQ panels and the image lightbox.

## How the files connect

Every HTML page links to `style.css` in the same root folder and loads `js/main.js` using a relative path. All navigation links point to the five local HTML files. Keep the `js` folder beside the HTML files; do not move `main.js` without updating the script path.

## How to test locally

1. Extract the ZIP file.
2. Open the project folder in Visual Studio Code.
3. Open `index.html` with Live Server or another local static server.
4. Navigate through all five pages using the shared navigation.
5. On Products, search for “cake”, “bread” or “pastry”; confirm cards filter and the count updates.
6. Click or keyboard-activate a product image; close the lightbox with Close or Escape.
7. On About, open and close each FAQ answer.
8. On Enquiry, submit an empty form to check validation, then test a valid product and quantity. Check the estimate and email draft.
9. On Contact, test missing fields and a valid general message. Confirm that the mail app opens where configured.
10. Use browser developer tools at desktop, tablet and mobile widths. Capture screenshots for the final submission and add them to the repository.

## Deployment checklist

1. Push the complete folder to the lecturer-provided GitHub repository.
2. For GitHub Pages, configure the repository's Pages source to the correct branch/folder; alternatively, deploy the folder to Netlify.
3. Open the published URL and test every page, image, form, search interaction and lightbox.
4. Replace the placeholder domain in `robots.txt` and `sitemap.xml` with the real published domain.
5. Add the published URL and screenshots to the submission/README after deployment. A live URL is not included here because deployment must be performed from the student's own account.

## Changelog

### Part 3 — 20 October 2026
- Fixed a bug where stray literal `\n` text was written into the head/body of every HTML page and appeared on screen.
- Fixed a broken `class="\1 js-lightbox-image"` on the four product images (now `product-image js-lightbox-image`).
- Added `<meta name="keywords">` to all five pages.
- Replaced the generic one-location Google Maps iframe with an interactive Leaflet map showing both branches.
- Added product sorting (name/price) beside the search filter, using `data-name` and `data-price` attributes.
- Added CSS transitions and keyframe animations, plus a global `[hidden]` rule so filtered cards and FAQ panels always hide correctly.
- Strengthened validation: phone numbers need at least 9 digits, collection date cannot be in the past, contact message needs at least 10 characters.
- Added a shared `js/main.js` file and linked it to all five HTML pages using `defer`.
- Added live product search/filtering and a dynamic visible-product count to `products.html`.
- Added an accessible product-image lightbox with keyboard activation, Escape-to-close and focus restoration.
- Added an FAQ accordion to `about.html`.
- Added JavaScript client-side validation and accessible error feedback for the enquiry and contact forms.
- Added product enquiry processing that calculates a clearly labelled example starting-price estimate for products with listed example prices.
- Added JavaScript-generated email drafts for the bakery's existing recipient address; documented the `mailto:` limitation.
- Refined page-specific title tags and meta descriptions and added a theme colour meta tag.
- Added `robots.txt` and `sitemap.xml` templates; the deployment domain must be filled in after publication.
- Extended `style.css` for the new interactive components, form feedback and reduced-motion preferences while retaining Part 2's visual identity and responsive rules.

### Part 2 — carried forward
- Retained the shared external stylesheet, CSS reset, responsive desktop/tablet/mobile layouts, Grid/Flexbox, responsive images, form styling and focus/hover states.
- Retained the five original pages and internal navigation.

### Part 1 — carried forward
- Retained the Urban Crust Bakery project concept, mission, vision, target customers, product categories and basic sitemap.

### Lecturer feedback
Record actual feedback from Parts 1 and 2 here and describe the exact changes made. Do not leave example feedback as if it were received.

## References (Harvard style)

Google (n.d.) *Google Maps*. Available at: https://www.google.com/maps (Accessed: 20 October 2026).

MDN Web Docs (n.d.) *Constraint validation*. Available at: https://developer.mozilla.org/en-US/docs/Web/HTML/Constraint_validation (Accessed: 20 October 2026).

MDN Web Docs (n.d.) *Document Object Model (DOM)*. Available at: https://developer.mozilla.org/en-US/docs/Web/API/Document_Object_Model (Accessed: 20 October 2026).

MDN Web Docs (n.d.) *The `<meta>` element*. Available at: https://developer.mozilla.org/en-US/docs/Web/HTML/Element/meta (Accessed: 20 October 2026).

Leaflet (n.d.) *Leaflet: an open-source JavaScript library for interactive maps*. Available at: https://leafletjs.com/ (Accessed: 20 October 2026).

OpenStreetMap (n.d.) *OpenStreetMap*. Available at: https://www.openstreetmap.org/copyright (Accessed: 20 October 2026).

Sitemaps.org (n.d.) *Sitemaps XML format*. Available at: https://www.sitemaps.org/protocol.html (Accessed: 20 October 2026).

Unsplash (n.d.) *Unsplash image library*. Available at: https://unsplash.com/ (Accessed: 20 October 2026). Image URLs already present in the inherited Part 2 files should be checked against their individual source/licence details before submission.

OpenAI (2026) *ChatGPT* [AI assistant]. Used for assistance with planning, code drafting and documentation for Part 3. The student should follow the institution's current AI disclosure requirements and include the required disclosure annexure and screenshots.

## Final submission reminders

- Confirm the lecturer's feedback from Part 2 has been applied and recorded.
- Check all image licences and provide specific image credits where required.
- Update the sitemap and robots file with the deployed URL.
- Add desktop/tablet/mobile screenshots and the final GitHub/deployment links.
- Test the website yourself and make sure you understand the JavaScript before submission.
