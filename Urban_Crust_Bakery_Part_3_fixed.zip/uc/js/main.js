/* Urban Crust Bakery — Part 3 JavaScript
   Features: product search, image lightbox, FAQ accordion and validated email forms.
*/
"use strict";

document.addEventListener("DOMContentLoaded", () => {
    initialiseProductSearch();
    initialiseLightbox();
    initialiseFaq();
    initialiseProductSort();
    initialiseEmailForms();
    initialiseBranchMap();
    setMinimumCollectionDate();
});

/* Filter product cards by product name and description as the visitor types. */
function initialiseProductSearch() {
    const search = document.querySelector("#productSearch");
    const cards = [...document.querySelectorAll(".product-card")];
    const count = document.querySelector("#productCount");
    if (!search || !cards.length || !count) return;

    const updateProducts = () => {
        const term = search.value.trim().toLocaleLowerCase();
        let visible = 0;
        cards.forEach((card) => {
            const matches = card.textContent.toLocaleLowerCase().includes(term);
            card.hidden = !matches;
            if (matches) visible += 1;
        });
        count.textContent = visible === 1 ? "Showing 1 product." : `Showing ${visible} products.`;
        if (visible === 0) count.textContent = "No products match your search. Try another word.";
    };
    search.addEventListener("input", updateProducts);
    updateProducts();
}

/* Build one reusable lightbox modal and open it when a product image is activated. */
function initialiseLightbox() {
    const images = [...document.querySelectorAll(".js-lightbox-image")];
    if (!images.length) return;

    const modal = document.createElement("div");
    modal.className = "lightbox";
    modal.id = "imageLightbox";
    modal.setAttribute("role", "dialog");
    modal.setAttribute("aria-modal", "true");
    modal.setAttribute("aria-label", "Enlarged product image");
    modal.hidden = true;
    modal.innerHTML = `
        <button class="lightbox-close" type="button" aria-label="Close enlarged image">Close ✕</button>
        <figure>
            <img alt="">
            <figcaption class="lightbox-caption"></figcaption>
        </figure>`;
    document.body.appendChild(modal);

    const largeImage = modal.querySelector("img");
    const caption = modal.querySelector("figcaption");
    const closeButton = modal.querySelector(".lightbox-close");
    let lastFocused = null;

    const open = (image) => {
        lastFocused = image;
        largeImage.src = image.currentSrc || image.src;
        largeImage.alt = image.alt || "Bakery product";
        caption.textContent = image.alt || "Bakery product image";
        modal.hidden = false;
        document.body.classList.add("modal-open");
        closeButton.focus();
    };
    const close = () => {
        modal.hidden = true;
        document.body.classList.remove("modal-open");
        if (lastFocused) lastFocused.focus();
    };

    images.forEach((image) => {
        image.addEventListener("click", () => open(image));
        image.addEventListener("keydown", (event) => {
            if (event.key === "Enter" || event.key === " ") {
                event.preventDefault();
                open(image);
            }
        });
    });
    closeButton.addEventListener("click", close);
    modal.addEventListener("click", (event) => {
        if (event.target === modal) close();
    });
    document.addEventListener("keydown", (event) => {
        if (!modal.hidden && event.key === "Escape") close();
    });
}

/* Accessible accordion: each button controls one answer panel. */
function initialiseFaq() {
    document.querySelectorAll(".faq-toggle").forEach((button) => {
        button.addEventListener("click", () => {
            const expanded = button.getAttribute("aria-expanded") === "true";
            const answer = document.getElementById(button.getAttribute("aria-controls"));
            button.setAttribute("aria-expanded", String(!expanded));
            if (answer) answer.hidden = expanded;
        });
    });
}

/* Validate the two distinct forms, prepare a readable email and open the visitor's email app.
   This is a static-site workflow: it does not store or transmit form data to a server. */
function initialiseEmailForms() {
    document.querySelectorAll("form[data-form-kind]").forEach((form) => {
        form.addEventListener("submit", (event) => {
            event.preventDefault();
            clearFormErrors(form);
            const feedback = form.querySelector(".form-feedback");
            const invalidFields = [...form.querySelectorAll("input, select, textarea")]
                .filter((field) => !field.checkValidity() || hasTooFewDigits(field));

            if (invalidFields.length) {
                invalidFields.forEach((field) => {
                    field.setAttribute("aria-invalid", "true");
                    const error = document.createElement("small");
                    error.className = "field-error";
                    error.id = `${field.id || field.name}-error`;
                    error.textContent = field.validationMessage || "Please enter at least 9 digits for the phone number.";
                    field.insertAdjacentElement("afterend", error);
                    field.setAttribute("aria-describedby", error.id);
                });
                if (feedback) {
                    feedback.className = "form-feedback error";
                    feedback.textContent = "Please correct the highlighted fields before continuing.";
                }
                invalidFields[0].focus();
                return;
            }

            const kind = form.dataset.formKind;
            const data = new FormData(form);
            let subject = "";
            let lines = [];

            if (kind === "enquiry") {
                const product = data.get("Product") || "Product enquiry";
                subject = `Product enquiry: ${product}`;
                lines = [
                    "URBAN CRUST BAKERY — PRODUCT ENQUIRY",
                    `Name: ${data.get("Full Name")}`,
                    `Email: ${data.get("Email")}`,
                    `Phone: ${data.get("Phone Number")}`,
                    `Product: ${product}`,
                    `Quantity: ${data.get("Quantity")}`,
                    `Preferred collection date: ${data.get("Collection Date") || "Not specified"}`,
                    `Custom cake requirements: ${data.get("Custom Cake Requirements") || "None supplied"}`
                ];
                const quantity = Number(data.get("Quantity"));
                const prices = {
                    "Chocolate Celebration Cake": 350,
                    "Vanilla Cupcakes": 120,
                    "Fresh Bread": 25,
                    "Apple Pastry": 30
                };
                const price = prices[product];
                if (feedback) {
                    feedback.className = "form-feedback success";
                    feedback.textContent = price
                        ? `Enquiry checked. The listed starting price is R${price} per selected item/box; the bakery must confirm the final price and availability. Estimated listed starting total for ${quantity} item(s): R${(price * quantity).toFixed(2)}.`
                        : "Enquiry checked. Custom cake pricing and availability must be confirmed by the bakery.";
                }
            } else {
                subject = `Website message: ${data.get("Message Type")}`;
                lines = [
                    "URBAN CRUST BAKERY — GENERAL MESSAGE",
                    `Name: ${data.get("Name")}`,
                    `Email: ${data.get("Email")}`,
                    `Message type: ${data.get("Message Type")}`,
                    "",
                    "Message:",
                    `${data.get("Message")}`
                ];
                if (feedback) {
                    feedback.className = "form-feedback success";
                    feedback.textContent = "Your message has been validated. Your email application should open with the message prepared; review it and press Send to deliver it.";
                }
            }

            const recipient = "info@urbancrustbakery.co.za";
            const mailto = `mailto:${recipient}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(lines.join("\n"))}`;
            window.location.href = mailto;
        });
    });
}

function clearFormErrors(form) {
    form.querySelectorAll(".field-error").forEach((error) => error.remove());
    form.querySelectorAll("[aria-invalid='true']").forEach((field) => {
        field.removeAttribute("aria-invalid");
        field.removeAttribute("aria-describedby");
    });
}

/* Sort visible product cards by name or listed starting price (reorders the DOM). */
function initialiseProductSort() {
    const select = document.querySelector("#productSort");
    const grid = document.querySelector(".product-grid");
    if (!select || !grid) return;
    const original = [...grid.children];
    select.addEventListener("change", () => {
        const cards = [...original];
        if (select.value === "name") cards.sort((a, b) => a.dataset.name.localeCompare(b.dataset.name));
        if (select.value === "price-asc") cards.sort((a, b) => a.dataset.price - b.dataset.price);
        if (select.value === "price-desc") cards.sort((a, b) => b.dataset.price - a.dataset.price);
        cards.forEach((card) => grid.appendChild(card));
    });
}

/* Interactive Leaflet map: one marker per branch. Coordinates are example values for the fictional addresses. */
function initialiseBranchMap() {
    const el = document.querySelector("#branchMap");
    if (!el) return;
    if (typeof L === "undefined") {
        el.textContent = "The map could not be loaded. Please check your internet connection.";
        return;
    }
    const branches = [
        { name: "Main Branch", address: "25 Bakery Street, Johannesburg", coords: [-26.2041, 28.0473] },
        { name: "Community Branch", address: "10 Market Road, Johannesburg", coords: [-26.1952, 28.0340] }
    ];
    const map = L.map(el).setView([-26.1996, 28.0407], 13);
    L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
        maxZoom: 19,
        attribution: "&copy; OpenStreetMap contributors"
    }).addTo(map);
    branches.forEach((b) => L.marker(b.coords).addTo(map).bindPopup(`<strong>${b.name}</strong><br>${b.address}`));
    map.fitBounds(branches.map((b) => b.coords), { padding: [40, 40] });
}

/* Stop visitors choosing a collection date in the past. */
function setMinimumCollectionDate() {
    const date = document.querySelector("#date");
    if (!date) return;
    const today = new Date();
    today.setMinutes(today.getMinutes() - today.getTimezoneOffset());
    date.min = today.toISOString().split("T")[0];
}

/* A phone number must contain at least 9 digits, not just symbols. */
function hasTooFewDigits(field) {
    return field.type === "tel" && field.value.replace(/\D/g, "").length < 9;
}
